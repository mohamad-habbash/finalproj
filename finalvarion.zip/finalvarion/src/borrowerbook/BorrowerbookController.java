/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package borrowerbook;


import dbconn.connecteddb;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author Educ
 */
public class BorrowerbookController implements Initializable {

     connecteddb c = new connecteddb();
 
    @FXML
    private TextField textfiledbookid;
    @FXML
    private TextField textfiledborrowerid;
    @FXML
    private Button buttonaddallbook;
    @FXML
    private TextField textfiledborrower_date;
    @FXML
    private TextField textfiledreturn_date;

  
    @Override
    public void initialize(URL url, ResourceBundle rb) {
          c.getconnectiondb();
    }    

 

    @FXML
    private void buttonaddallbookhandle(ActionEvent event) {
        int  boid = Integer.parseInt(textfiledbookid.getText());
        int  brid = Integer.parseInt(textfiledborrowerid.getText());
        double  borda = Double.parseDouble(textfiledborrower_date.getText());
        double  reda = Double.parseDouble(textfiledreturn_date.getText());
          
       
        int stuts = c.addbokbro(boid, brid , borda, reda);

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("ADD borrower_BOOK  ");
        alert.setHeaderText("Do you really want to add borrower_BOOK the book ?");
        alert.setContentText("add borrower_BOOK");
        alert.showAndWait();
        //
        switch (stuts) {
            case 0: {
                System.out.println("done addeed");
            }
            break;
            case -1:
                Alert alerts = new Alert(Alert.AlertType.ERROR);
                alerts.setTitle("error retrive");
                alerts.setContentText("error to add book");
                break;
            case 1:
                Alert aler = new Alert(Alert.AlertType.ERROR);
                aler.setTitle("susses retrive");
                aler.setContentText("sussesful to add book");
                break;
        }

    }
    
}
